<?php
/*
Plugin Name: User Registration Form
Plugin URI: https://github.com/iSohaibKhan/registrationForm
Description: A custom shortcode plugin to create a user registration form ( SHORTCODE = [epur_user_registration_form] ).
Version: 1.0.4
Author: Sohaib S. Khan
Author URI: https://isohaibkhan.github.io/
License: GPL2
*/

// Prevent direct access
defined('ABSPATH') or die('Access denied');

// Enqueue styles for the plugin
function epur_enqueue_styles() {
    wp_enqueue_style('epur-styles', plugin_dir_url(__FILE__) . 'assets/style.css');
}
add_action('wp_enqueue_scripts', 'epur_enqueue_styles');

// Register shortcode for user registration form
function epur_user_registration_form_shortcode() {
    ob_start();

    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['epur_register_user'])) {
        $first_name = sanitize_text_field($_POST['epur_first_name']);
        $last_name = sanitize_text_field($_POST['epur_last_name']);
        $username = sanitize_user($_POST['epur_username']);
        $email = sanitize_email($_POST['epur_email']);
        $password = sanitize_text_field($_POST['epur_password']);

        $errors = [];

        if (empty($username) || empty($email) || empty($password) || empty($first_name) || empty($last_name)) {
            $errors[] = 'All fields are required.';
        } elseif (!is_email($email)) {
            $errors[] = 'Invalid email address.';
        } elseif (username_exists($username) || email_exists($email)) {
            $errors[] = 'Username or email already exists.';
        }

        if (empty($errors)) {
            $user_id = wp_create_user($username, $password, $email);

            if (!is_wp_error($user_id)) {
                wp_update_user([
                    'ID' => $user_id,
                    'first_name' => $first_name,
                    'last_name' => $last_name
                ]);

                echo '<p class="epur-success">Registration successful! You can now log in.</p>';
            } else {
                echo '<p class="epur-error">' . $user_id->get_error_message() . '</p>';
            }
        } else {
            foreach ($errors as $error) {
                echo '<p class="epur-error">' . esc_html($error) . '</p>';
            }
        }
    }

    // Display the registration form
    ?>
    <form method="post" class="epur-registration-form">
        <p>
            <label for="epur_first_name">First Name</label>
            <input type="text" name="epur_first_name" id="epur_first_name" placeholder="John" required>
        </p>
        <p>
            <label for="epur_last_name">Last Name</label>
            <input type="text" name="epur_last_name" id="epur_last_name" placeholder="Doe" required>
        </p>
        <p>
            <label for="epur_username">Username</label>
            <input type="text" name="epur_username" id="epur_username" placeholder="iJohnDoe" required>
        </p>
        <p>
            <label for="epur_email">Email</label>
            <input type="email" name="epur_email" id="epur_email" placeholder="johndoe@example.com" required>
        </p>
        <p>
            <label for="epur_password">Password</label>
            <input type="password" name="epur_password" id="epur_password" placeholder="********" required>
        </p>
        <p>
            <button type="submit" name="epur_register_user">Register</button>
        </p>
    </form>
    <?php

    return ob_get_clean();
}

add_shortcode('epur_user_registration_form', 'epur_user_registration_form_shortcode');